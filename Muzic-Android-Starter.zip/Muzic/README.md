# Muzic — Offline Android Music Player

This is a starter Android Studio project for an offline music player.

## Included
- Reads music indexed by Android MediaStore
- Requests audio-library permission
- Lists local music tracks
- Play, pause, next, previous
- Dark purple UI

## Build
1. Install Android Studio (latest stable).
2. Open this `Muzic` folder in Android Studio.
3. Let Gradle sync finish.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

The app asks permission to read audio files. Add MP3/audio files to the phone's Music folder and make sure Android has indexed them.

## Current starter limitations
This first version is a foundation. Background playback after the app is closed, notification controls, playlists, favourites, album artwork, search, and shuffle/repeat are not included yet.

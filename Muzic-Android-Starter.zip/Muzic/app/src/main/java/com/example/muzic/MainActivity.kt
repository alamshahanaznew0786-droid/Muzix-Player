package com.example.muzic

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private var currentIndex by mutableIntStateOf(-1)
    private var isPlaying by mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadTracks()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MuzicScreen(
                tracks = tracks,
                currentIndex = currentIndex,
                isPlaying = isPlaying,
                onTrackClick = { playTrack(it) },
                onPlayPause = { togglePlayback() },
                onNext = { playNext() },
                onPrevious = { playPrevious() }
            )
        }
        requestAudioPermission()
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    private fun loadTracks() {
        val found = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                val uri = ContentUris.withAppendedId(collection, id)
                found += Track(id, title, artist, uri)
            }
        }
        tracks = found
    }

    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, tracks[index].uri)
            setOnCompletionListener { playNext() }
            prepare()
            start()
        }
        currentIndex = index
        isPlaying = true
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            if (tracks.isNotEmpty()) playTrack(0)
        } else if (p.isPlaying) {
            p.pause()
            isPlaying = false
        } else {
            p.start()
            isPlaying = true
        }
    }

    private fun playNext() {
        if (tracks.isNotEmpty()) playTrack((currentIndex + 1).mod(tracks.size))
    }

    private fun playPrevious() {
        if (tracks.isNotEmpty()) playTrack(if (currentIndex <= 0) tracks.lastIndex else currentIndex - 1)
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
fun MuzicScreen(
    tracks: List<Track>,
    currentIndex: Int,
    isPlaying: Boolean,
    onTrackClick: (Int) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    val bg = Color(0xFF101018)
    val panel = Color(0xFF202033)
    val purple = Color(0xFF9B7BFF)
    val current = tracks.getOrNull(currentIndex)

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().background(bg).padding(20.dp)
        ) {
            Text("Muzic", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("YOUR OFFLINE MUSIC", color = purple, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(22.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Your songs", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${tracks.size} tracks", color = Color.LightGray, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))

            if (tracks.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No music found yet. Add audio files to your phone.", color = Color.LightGray)
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(tracks) { index, track ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (index == currentIndex) panel else Color(0xFF171722), RoundedCornerShape(14.dp))
                                .clickable { onTrackClick(index) }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("♫", color = purple, fontSize = 22.sp, modifier = Modifier.padding(end = 12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1)
                                Text(track.artist, color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
                            }
                            if (index == currentIndex) Text("PLAYING", color = purple, fontSize = 10.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().background(panel, RoundedCornerShape(18.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(current?.title ?: "Choose a song", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(current?.artist ?: "Muzic player", color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
                }
                TextButton(onClick = onPrevious) { Text("◀", color = Color.White, fontSize = 18.sp) }
                Button(
                    onClick = onPlayPause,
                    colors = ButtonDefaults.buttonColors(backgroundColor = purple),
                    shape = RoundedCornerShape(50)
                ) { Text(if (isPlaying) "Ⅱ" else "▶", color = Color.White, fontSize = 18.sp) }
                TextButton(onClick = onNext) { Text("▶|", color = Color.White, fontSize = 18.sp) }
            }
        }
    }
}
